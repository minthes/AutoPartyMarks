local function SetMarks()
    local inInstance, instanceType = IsInInstance()
    if instanceType == "arena" then
        if UnitExists("player") then
            SetRaidTarget("player", 8)
        end
        if UnitExists("party1") then
            SetRaidTarget("party1", 7)
        end
        if UnitExists("pet") then
            SetRaidTarget("pet", 4)
        end
        if UnitExists("party1pet") then
            SetRaidTarget("party1pet", 3)
        end
        if UnitExists("party2pet") then
            SetRaidTarget("party2pet", 5)
        end
    end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PARTY_MEMBERS_CHANGED")
f:RegisterEvent("UNIT_PET")
f:RegisterEvent("UNIT_TARGET")
f:RegisterEvent("PLAYER_ENTERING_WORLD") 

function f:OnEvent(event, arg1)
    if event == "PARTY_MEMBERS_CHANGED" or event == "UNIT_PET" or (event == "UNIT_TARGET" and arg1 == "player") or event == "PLAYER_ENTERING_WORLD" then
        SetMarks()
    end
end

f:SetScript("OnEvent", f.OnEvent)
